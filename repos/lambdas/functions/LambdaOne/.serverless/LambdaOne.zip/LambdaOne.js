
module.exports.hello = (event, context, callback)=> {
    return 'hello World222'
}
