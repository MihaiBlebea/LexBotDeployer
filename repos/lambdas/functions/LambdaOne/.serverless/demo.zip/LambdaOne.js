
module.exports.hello = (event, context, callback)=> {
    return 'hello World222'
    console.log('c2')
}
