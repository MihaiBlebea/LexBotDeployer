
module.exports.hello = (event, context, callback)=> {
    console.log('ceva')
    return 'hello World22'
}
