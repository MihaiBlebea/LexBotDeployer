
module.exports.hello = (event, context, callback)=> {
    console.log('cevass')
    return 'hello World22'
}
