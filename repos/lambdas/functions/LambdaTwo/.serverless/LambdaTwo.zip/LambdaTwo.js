
module.exports.goodbye = (event, context, callback)=> {
    return 'Goodbye World33'
    console.log('serban Mihai B')
}
