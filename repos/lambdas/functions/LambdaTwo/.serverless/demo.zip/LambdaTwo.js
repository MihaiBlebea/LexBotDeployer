
module.exports.goodbye = (event, context, callback)=> {
    return 'Goodbye World33'
    console.log('22ww22')
}
